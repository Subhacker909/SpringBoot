package in.sp.main;

import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class CalcApp
{
	public static void main(String[] args) throws Exception
	{
		System.out.println("--------------Application Started--------------");
		
		FileHandler fileHandler = new FileHandler("d://calc.log", true);
		SimpleFormatter simpleFormatter = new SimpleFormatter();
		fileHandler.setFormatter(simpleFormatter);
		
		Logger logger = Logger.getLogger(CalcApp.class.getName());
		logger.addHandler(fileHandler);
		
		Scanner scanner = new Scanner(System.in);
		
		String yn = "";
		
		do
		{
			try
			{
				System.out.println("Enter no 1 : ");
				int no1 = scanner.nextInt();
				logger.log(Level.INFO, "Enter no 1 : "+no1);
				
				System.out.println("Enter no 2 : ");
				int no2 = scanner.nextInt();
				logger.log(Level.INFO, "Enter no 2 : "+no2);
				
				System.out.println("Select the symbol [+, -, *, /] : ");
				String symbol = scanner.next();
				logger.log(Level.INFO, "Select the symbol [+, -, *, /] : "+symbol);
				
				int res=0;
				
				switch(symbol)
				{
					case "+":
						res = no1+no2;
						System.out.println("Sum is : "+res);
						logger.log(Level.INFO, "Sum is : "+res);
						break;
						
					case "-":
						res = no1-no2;
						System.out.println("Sub is : "+res);
						logger.log(Level.INFO, "Sub is : "+res);
						break;
						
					case "*":
						res = no1*no2;
						System.out.println("Multiplication is : "+res);
						logger.log(Level.INFO, "Multiplication is : "+res);
						break;
						
					case "/":
						res = no1/no2;
						System.out.println("Division is : "+res);
						logger.log(Level.INFO, "Division is : "+res);
						break;
						
					default:
						System.out.println("Invalid Symbol");
						logger.log(Level.INFO, "Invalid Symbol");
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
				logger.log(Level.SEVERE, e.toString());
			}
			
			System.out.println("Do you want to continue, press y for yes else n for no : ");
			yn = scanner.next();
			logger.log(Level.INFO, "Do you want to continue, press y for y else n for no : "+yn);
			
		}while(yn.equals("Y") || yn.equals("y"));
		
		System.out.println("--------------Application Finished--------------");
	}
}